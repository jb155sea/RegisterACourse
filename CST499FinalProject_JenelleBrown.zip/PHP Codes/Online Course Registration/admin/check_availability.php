<?php 
require_once("includes/config.php");
if(!empty($_POST["studentID"])) {
	$studentID=$_POST["studentID"];
	
		$result=mysqli_query($bd, "SELECT studentID FROM students WHERE studentID='$studentID'");
		$count=mysqli_num_rows($result);
if($count>0)
{
echo "<span style='color:red'> This Student ID is already registered.</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
} else{
	

}
}


?>
