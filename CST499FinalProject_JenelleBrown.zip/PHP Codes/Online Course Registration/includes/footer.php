<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2024 Online Course | Course ABC
                </div>

            </div>
        </div>
    </footer>

    <style> .col-md-12{text-align: center;} </style>
